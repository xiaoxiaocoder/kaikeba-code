import css from "./index.css";
// import pic from "./logo.png";
// import { str } from "./a.js"; //.js .json
// import "./index.css";
//动态引入 和 代码拆分
console.log(str, "1");
